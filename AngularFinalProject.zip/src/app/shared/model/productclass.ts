export interface IProduct {
    id:number,
    fullname:string,
    contact:number,
    email:string,
    qualification:string,
    specification:string,
    appearing:string,
    passout:number,
    college:string,
    city:string,
    workexp:number,
    orgni:string,
    lighthousebranch:string,
    course:string,
    batch:string,
    wheredid:string
}   