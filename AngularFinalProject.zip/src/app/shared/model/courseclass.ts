export interface ICourses{
    id:number,
    cname:string,
    duration:number,
    cfees:number,
    trainerName:string,
    monyer:string
}