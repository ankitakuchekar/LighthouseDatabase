export interface ILighthouse{
    id:number,
    lname:string,
    lcontact:number,
    laddress1:string,
    laddress2:string,
    laddresscity:string,
    laddressstate:string,
    laddresspin:number
}