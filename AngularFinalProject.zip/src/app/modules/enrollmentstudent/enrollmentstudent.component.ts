import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enrollmentstudent',
  templateUrl: './enrollmentstudent.component.html',
  styleUrls: ['./enrollmentstudent.component.css']
})
export class EnrollmentstudentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
